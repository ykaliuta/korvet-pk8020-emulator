# encoding: UTF-8 
require 'ap'
$stdout.sync = true

def proceess_asm(fname)
	return  unless fname =~ /extrom-patcher-(.*?)\.asm/
	base=$1
	ap [base,fname]
	body=File.readlines(fname)
	label=nil

	body=body.map { |e| e.sub(/\s*;.*$/,'') }
	body=body.reject { |e| e=~/^\s*$/ }

	out=[]

	while body.size>0
		line=body.shift
		line.force_encoding("utf-8")
		# ap [line]
		case line
		when /^(.*?):/
			label=$1
			p [:label,label]
			out<<label
		when /^\tdb\s+(p.*?)\s+$/i
			type=$1
			case type
			when /pB_CHK_PATCH/i
				_addr=body.shift
				_values=body.shift
				# ap [:db,_addr,_values]

				addr=_addr.match(/dw\s+(\S+)/i)[1]
				vold,vnew=_values.match(/db\s+(.*?)\s*,\s*(.*?)\s*$/i)[1..2]

				p [:chk_db,addr,vold,vnew]
				out << [:db,addr,vold,vnew]
			when /pW_CHK_PATCH/i
				_addr_vals=body.shift
				# ap [:dw,_addr_vals]

				addr,vold,vnew=_addr_vals.match(/dw\s+(.*?)\s*?,\s*?(.*?)\s*,\s*(.*?)\s*$/i)[1..3]

				p [:chk_dw,addr,vold,vnew]
				out << [:dw,addr,vold,vnew]
			when /pW_STORE/i
				# db 	pW_STORE
				# dw 	0xE06E,r_p_SELDSKDRIVER+1	 
				_addr_vals=body.shift
				# ap [:store,_addr_vals]

				addr,value=_addr_vals.match(/dw\s+(.*?)\s*,\s*(.*?)\s*$/i)[1..2]

				p [:store_,addr,value]
				out << [:st,addr,value]
			when /p_STOP/i
				_addr_vals=body.shift
				text=_addr_vals.match(/db\s+('.*?')/i)[1]
				p [:stop_,text]
				out << [:stop,text]
			when /pNotSupported/i
				p [:NotSup]
				out << [:NotSup]
			when /pSETFLAG_MICRODOS/i
				p [:MICRDOS]
				out << [:MICRDOS]
			when /pREQUIRED_OPTS1/i
				p [:RQOPTS1]
				out << [:RQOPTS1]
			when /pREQUIRED_OPTS2/i
				p [:RQOPTS2]
				out << [:RQOPTS2]
			else 
				raise "unsoported type: >#{type}<"
			end
		else
			# p [:skip,line]
		end

	end
	out
end



out=[]
flist=Dir["./extrom-patcher-*.*"].sort.reject{|v| v=~/-(resident|_XXX)/}
cpm=flist.select{|v| v=~/-patcher-\d/}
microdos=flist.select{|v| v=~/-patcher-MICRODOS/}


# work_list=flist-cpm-microdos
work_list=cpm

# work_list=["./extrom-patcher-21_89___wiza.asm","./extrom-patcher-MICRODOS_2_900105.asm"]
work_list=["./extrom-patcher-1x_88_EPSON_V104.asm"]
work_list.each{|f| 
	v=proceess_asm(f)
	out << v.flatten
}


max=out.map{|v| v.size}.max
0.upto(max) do |idx|
	out.each do |bios|
		r=''
		r=bios[idx] if bios.size>=idx
		print "#{r};"
	end
	puts
end
