require 'ap'
$stdout.sync = true

class Checker
	def initialize(stage2_file,offset)
		@detector_data=File.open(stage2_file,"r:ascii").read.unpack("C*")[offset..-1]
		# ap @body.size
	end

	def check_file(file_name)

		result="nil"
		crc_ok,load_addr,size,ram=get_file(file_name)
		ap [crc_ok,"%04x" % load_addr,size]
		if crc_ok
			if load_addr == 0
				result="BAD_#{"%04x" % load_addr}_#{size}"
			elsif load_addr == 0xee && (size == 0x0e*1024) 
				result = "CPM_NET_KORNET_drive_b"
			else
				result=detector(ram)
			end
			# case size
			# when 10240,13312,14336
				# result=detector(ram)
			# when 13312			
			# 	result=":MICRODOS_1_13312"
			# when 14336			
				# result=":MICRODOS_2_14336"
			# else 
				# result=size.to_s
			# end
		else
			result=:crc_failed
		end
		result
	end

	def detector(ram)
		ptr=0
		# ap [ram.map{|v| "%02x" % v}]
		name=" -- undefied -- "
		run=true
		work=@detector_data.dup.clone
		found_flag=true
		while run do
			b=work[ptr];ptr+=1
			# p ["%04x" % (ptr-1),"%02x" % b]
			case b
			when 0xff # stop
				run=false
			when 0 # stop
				tmp=""
				while work[ptr] != 0 do
					tmp+=work[ptr].chr
					ptr+=1
				end
				ptr+=1

				if found_flag
					run=false
					name=tmp 
				else
					found_flag=true
					name=" -- undefied -- "
				end

			when 1 # word chk patch
				#addr,old,new
				addr=work[ptr]+(work[ptr+1]<<8);ptr+=2
				vold=work[ptr]+(work[ptr+1]<<8);ptr+=2
				vnew=work[ptr]+(work[ptr+1]<<8);ptr+=2

				in_ram=ram[addr]+(ram[addr+1]<<8)
				found_flag=false unless in_ram == vold
				# p [:word,addr,"%04x" % addr,"%04x" % vold,"%04x" % in_ram]

			when 2 # byte chk patch
				#addr,old,new
				addr=work[ptr]+(work[ptr+1]<<8);ptr+=2
				vold=work[ptr];ptr+=1
				vnew=work[ptr];ptr+=1

				in_ram=ram[addr]
				found_flag=false unless in_ram == vold
				# p [:word,addr,"%04x" % addr,"%02x" % vold,"%02x" % in_ram]
			when 4 # word store
				#addr,value
				addr=work[ptr]+(work[ptr+1]<<8);ptr+=2
				vnew=work[ptr]+(work[ptr+1]<<8);ptr+=2
				# p [:store,"%04x" % addr,"%04x" % vnew]
			when 5 # Unsupported
			else 
				raise "Unsupported CODE #{"%04x" % ptr} : #{"%02x" % b}"
			end
		end
		name
	end

	def get_file(file_name)
		body=File.open(file_name,"r:ascii").read

		loadadress ,
		runadress  ,
		count      ,
		sizedisk   ,
		density    ,
		tpi        ,
		skewfactor ,
		secsize    ,
		inside     ,
		secpertrack,
		trkperdisk ,

		spt        ,		# No. of Logical ( 128-byte ) Sectors per Logical Track
		bsh        ,		# Block Shift - Block Size is given by 128 * 2^(BSH)
		blm        ,		# Block Mask - Block Size is given by 128 * (BLM +1)
		exm        ,		# Extent Mask ( see opposite )
		dsm        ,		# ����� ������ �� ����� � ������ ����� 1
		drm        ,		# ����� ������ � ���������� ����� ����� 1
		al0        ,		# ����������, ����� ����� ���������������
		al1        ,		# ��� ����������
		cks        ,		# ������ ������� �������� ����������
		ofs        ,		# ����� ��������� ������� �� �����
		checksum 			= body[0..31].unpack("SSSCCCCCCSS"+"SCCCSSCCSSC")

		file_body=body.unpack("C*")

		calculated_crc=file_body[0..31-1].reduce(0x66){|sum,n| (sum+n.ord)&0xff}

		ram=(0..loadadress-1).to_a.map{|v| 0x55}
		ram+=file_body[0..(count*1024)]
		[calculated_crc == checksum,loadadress,count*1024,ram]
	end		

end
z=Checker.new("stage2.rom",0x3dd)

flist=Dir["/home/esl/Dropbox/Emulator/Korvet/KorvetSoft/**/*"]
kdi=flist.select{|v| v=~/\.kdi$/i}.select{|v| !File.directory?(v)}

# kdi=Dir["../../*.kdi"]
# p	z.check_file("../../12_87_11_niijaf.kdi")
h_oscount={}
kdi.each do |f|
	# print "#{f} - "
	type=z.check_file(f)
	puts "%-30s - %s" % [type,f]
	h_oscount[type]||=0
	h_oscount[type]+=1

end
keys=h_oscount.keys.sort{|a,b| h_oscount[b] <=> h_oscount[a]}
keys.each do |k|
	puts "%-20s - %3d" % [k,h_oscount[k]]
end