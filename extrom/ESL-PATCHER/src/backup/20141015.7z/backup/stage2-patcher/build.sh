#!/bin/sh
zmac stage2.asm
if [ $? -ne 0 ];then
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
else
    cp zout/stage2.cim ../../stage2.rom
    cp zout/stage2.cim stage2.rom
    ( cd ../../..;./kdbg -e extrom/ -z )
fi

