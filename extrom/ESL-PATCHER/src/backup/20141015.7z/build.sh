#!/bin/sh
opts="korvet20.rom"
#opts="korvet11.rom"

zmac -m  stage2.asm
if [ $? -ne 0 ];then
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
   echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
else
    cp zout/stage2.cim ../../stage2.rom
    cp zout/stage2.cim stage2.rom
    ( cd ../../..;./kdbg -e extrom/ -z )
#    ( cd ../../..;./kdbg -r data/$opts -e extrom/ )
fi

