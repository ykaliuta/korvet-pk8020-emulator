﻿/*
 * AUTHOR: Sergey Erokhin                 esl@pisem.net,pk8020@gmail.com
 * &Korvet Team                                              2000...2005
 * ETALON Korvet Emulator                         http://pk8020.narod.ru
 * ---------------------------------------------------------------------
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111, USA.
 *
 */
#include "korvet.h"

#define noPPI_DEBUG

#ifdef TRACETIMER
extern int Takt;
extern F_TIMER;
#endif

extern int SYSREG;
extern int NCREG;

FILE* romlog=0;    // лог процесса загрузки из ROM

unsigned char emu_stage=0;	// этап обработки команд korvet-extrom
unsigned char fb[128];          // буфер сектора
unsigned char cmd,drv,trk,sec;      // параметры командного пакета korvet-extrom
unsigned int emu_byte;
unsigned char ex_flag=0;     // фдаг обращение к адресным портам при загрузке из внешнего ПЗУ

// --------------------------------------------------------------------------
// переменные из модуля экрана, собиракм и разбираем
// прямо при записи, чтении.
extern int scr_Page_Acces;       // Страница для достуап к видеопамяти   ViReg:xx000000
extern int scr_Page_Show;        // Страница для отображения             ViReg:000000xx
// АЦЗУ
extern int scr_Attr_Write;       // Атрибут для записи в АЦЗУ	         ViReg:00xx0000
extern int scr_Wide_Mode;        // Флаг режима 32 символа в строке      ViReg:0000x000
extern int scr_Second_Font;      // Флаг выбора второго знакогенератора  ViReg:00000x00

extern int scr_Attr_Read;        // Значени Инверсии при чтении 	 VisST:0000x000

extern int AllScreenUpdateFlag;  // Флаг необходимости обновть весь экран
extern int scr_GZU_Size_Mask;	 // маска размера ГЗУ, =0x0f - 4*48, =0 - 1x 48k
// -------------------------------------------------------------------------
// Переменная из модуля
extern int DRVREG;               // см. в модуле контролера дисковода

// -------------------------------------------------------------------------
// Переменная из модуля Звука (Флаг разрешения звука)
extern int SoundEnable;

// -------------------------------------------------------------------------
// Переменная из модуля Синхронизация.
extern int VBLANK;
extern int Takt;

extern int k_mousex;
extern int k_mousey;
extern int k_mouseb;

// -------------------------------------------------------------------------
// Переменная из модуля Принтера.
//extern int LSTSTS; // Признак готовности принтера PPI1, port A, Bit 00000x00
//extern int LSTCTL; // Строб записи

//
int PPI1_A,PPI1_B,PPI1_C,PPI1_RUS;
int PPI2_A,PPI2_B,PPI2_C,PPI2_RUS;
int PPI3_A,PPI3_B,PPI3_C,PPI3_RUS;

// Сброс адаптеров - все порты на вывод, значение - 0
void PPI_init() {

PPI1_A=0;
PPI1_B=0;
PPI1_C=0;
PPI1_RUS=0;
PPI2_A=0;
PPI2_B=0;
PPI2_C=0;
PPI2_RUS=0;
PPI3_A=0;
PPI3_B=0;
PPI3_C=0;
PPI3_RUS=0;
if ((romboot==1)&&(romlog == 0)) romlog=fopen("extrom.log","w"); // есди разрешена заргрузка по сети - формируем лог
}


// Все управляющие сигналы в собственных переменных,
// Assemble
//             - Собираем значение байта из отдельных переменных.
// Disassemble
//             - Разбираем байт на отедльные переменные.
//

byte Assemble_PPI1A(void)
{
   int Value=0;

   Value|=(LANADDR           &0x0f)<<4; // xxxx0000
   Value|=(scr_Attr_Read     &0x01)<<3; // 0000x000
   Value|=(GetPrinterStatus()&0x01)<<2; // 00000x00
   Value|=((Takt<VBLANK_TAKT)?1:0 )<<1; // 000000x0
//   Value|=(TapeIN  &0x01)<<0;        // 0000000x
   return Value;
}

void DisassembleVIREG_PPI1C(byte Value)
{
   static unsigned char cntr=0;

   scr_Page_Acces =(Value&0xc0)>>6;    // ViReg:xx000000
   scr_Attr_Write =(Value&0x30)>>4;    // ViReg:00xx0000
   scr_Wide_Mode  =(Value&0x08)>>3;    // ViReg:0000x000
   scr_Second_Font=(Value&0x04)>>2;    // ViReg:00000x00
   scr_Page_Show  =(Value&0x03)>>0;    // ViReg:000000xx

   // Обновить весь экран если установлен режим влияет на весь
   // экран. (ширина символов, знакогенератор, стр. отображения графики)
   if ( (PPI1_C&0x0f) != (Value&0x0f)) AllScreenUpdateFlag=1;

   scr_Page_Acces &= scr_GZU_Size_Mask;
   scr_Page_Show  &= scr_GZU_Size_Mask;

}

byte AssembleVIREG_PPI1C(void)
{
   int Value=0;
   Value|=(scr_Page_Acces &0x03)<<6;     // ViReg:xx000000
   Value|=(scr_Attr_Write &0x03)<<4;     // ViReg:00xx0000
   Value|=(scr_Wide_Mode  &0x01)<<3;     // ViReg:0000x000
   Value|=(scr_Second_Font&0x01)<<2;     // ViReg:00000x00
   Value|=(scr_Page_Show  &0x03)<<0;     // ViReg:000000xx
   return Value;
}

void Disassemble_PPI2C(int Value)
{
static int oldState_SoundEnable;
int tSoundEnable;

if ((((Value&0x80)>>7) == 1) && (romboot == 1)) PIC_IntRequest(0);    // формируем запрос прерывания extrom по сигналу control
//  Reset for Analog Joystick =(Value&0x40)>>6;
// ~SE               =(Value&0x20)>>5;

// ~ACK              =(Value&0x10)>>4;
//   SetPrinterStrobe((Value&0x10)>>4);
   SetPrinterStrobe((Value&0x20)>>4);

   tSoundEnable       =(Value&0x08)>>3;
// Cassete Motor ON  =(Value&0x04)>>2;
// CasseteOut level  =(Value&0x03)>>0;

   if (oldState_SoundEnable != tSoundEnable) {
     DoTimer();
   }

   SoundEnable=tSoundEnable;
   oldState_SoundEnable=SoundEnable;

#ifdef TRACETIMER
 fprintf(F_TIMER,"S: %08d %d\n",Takt,SoundEnable);
#endif
}

int Assemble_PPI2C(void)
{
    int Value=0;
//   XS1:32          =(Value&0x80)>>7;
//  Reset for Analog Joystick =(Value&0x40)>>6;
// ~SE               =(Value&0x20)>>5;
// ~ACK              =(Value&0x10)>>4;
   Value             =(SoundEnable&0x01)<<3;
// Cassete Motor ON  =(Value&0x04)>>2;
// CasseteOut level  =(Value&0x03)>>0;
   return Value;
}

void PPI1_Write(int Addr, byte Value) {
    int bit,oldc;

    switch (Addr & 0x03) {
      case 0: {PPI1_A=Value;break;}
      case 1: {FDC_Write_DRVREG(Value);break;}
      case 2: {
           DisassembleVIREG_PPI1C(Value);
           PPI1_C=Value;
           break;
      }
      case 3: {
           if (Value & 0x80) PPI1_RUS=Value;
           else {
             bit=1 << ( (Value & 0x0e) >> 1);
             oldc=PPI1_C;
             if (Value &1) oldc|=bit;
             else          oldc&=bit^0xff;
             DisassembleVIREG_PPI1C(oldc);
             PPI1_C=oldc;
           }
           break;
      }
    }
}

byte PPI1_Read(int Addr){
    int Value;
    switch (Addr & 0x03) {
      case 0: {Value=Assemble_PPI1A();break;}
      case 1: {Value=FDC_Read_DRVREG();break;}
      case 2: {Value=AssembleVIREG_PPI1C();break;}
      case 3: {return 0xff;break;}
    }
    return Value;
}

void PPI2_Write(int Addr, byte Value) {
    int bit;
    switch (Addr & 0x03) {
      case 0: {PPI2_A=Value;break;}
      case 1: {PPI2_B=Value;break;}
      case 2: {PPI2_C=Value;Disassemble_PPI2C(PPI2_C);break;}
      case 3: {
           if (Value & 0x80) PPI2_RUS=Value;
           else {
             bit=1 << ( (Value & 0x0e) >> 1);
             if (Value &1) PPI2_C|=bit;
             else          PPI2_C&=bit^0xff;
           }           Disassemble_PPI2C(PPI2_C);
           break;
      }
    }
}

byte PPI2_Read(int Addr){
    int Value;
    switch (Addr & 0x03) {
      case 0: {Value=PPI2_A;break;}
      case 1: {Value=PPI2_B;break;}
      case 2: {Value=PPI2_C=Assemble_PPI2C();break;}
      case 3: {return 0xff;break;}
    }
    return Value;
}

void PPI3_Write(int Addr, byte Value) {
    int bit;
    switch (Addr & 0x03) {
      case 0: {
        PPI3_A=Value;
        if ((PPI2_C&0x80) == 0) break;   // control=0 - все расширения неактивны 
        // Режим эмуляции korvet-extrom
        if (emuflag == 1) {
          switch(emu_stage) {
           case 0:			// CMD
             cmd=Value;
             emu_stage++;
             break;
           case 1:			// DRV
             drv=Value;
             emu_stage++;
             break;
           case 2:			// TRK
             trk=Value;
             emu_stage++;
             break;
           case 3:			// SEC
             sec=Value;
             emu_stage++;
             emu_byte=0;
             break;
           default:
             emu_stage=0;
          }
//          fprintf(romlog,"\n IOP3A w byte: %02x   stage=%i",Value,emu_stage);
          ex_flag=0;
         } 
        break;
        }
      case 1: {
        PPI3_B=Value;
//        emuflag=0;
	// загрузка из rom - установка младшего адреса
        if (romboot==1) fseek(extrom_file,(PPI3_C<<8)+Value,SEEK_SET);
        ex_flag=1;
        break;
       }
      case 2: {
        PPI3_C=Value;
//        emuflag=0;
	// загрузка из rom - установка старшего адреса
        if (romboot==1) fseek(extrom_file,(Value<<8)+PPI3_B,SEEK_SET);
        ex_flag=1;
        break;
       }
      case 3: {
           if (Value & 0x80) PPI3_RUS=Value;
           else {
             bit=1 << ( (Value & 0x0e) >> 1);
             if (Value &1) PPI3_C|=bit;
             else          PPI3_C&=bit^0xff;
           }
           break;
      }
    }

}

byte PPI3_Read(int Addr){
    int Value;
    switch (Addr & 0x03) {
      case 0: {
        Value=PPI3_A;
        if ((PPI2_C&0x80) == 0) break;   // control=0 - все расширения неактивны (иначе ошибка шины) 
       // Запуск загрузки с внешнего ПЗУ, если была предварительная запись адреса
       if ((romboot == 1) && (ex_flag == 1)) { 
	 // загрузка из ROM - достаем байт из файла образа
          Value=fgetc(extrom_file);
          fprintf(romlog,"\n %02x%02x: %02x",PPI3_C,PPI3_B,Value); // запись в логе обращений к ROM
          break;
        }
        // есть активная команда extrom - отдаем байт из буфера
       if ((emuflag == 1) && (emu_stage == 4)) {
        // обработки в зависимости от фазы передачи данных, определяемое emu_byte:
        // первый байт отдаваемого блока - позиционируемся на файл и читаем его
//         fprintf(romlog,"\n *** emu_byte = %i",emu_byte);
         if (emu_byte == 0) {   
            fseek(emu_file,(trk*40+sec)*128,SEEK_SET);
            fread(fb,1,128,emu_file);
            fprintf(romlog,"\n Rd: DRV:%i  TRK: %i  SEC:%i",drv,trk,sec);
         }
        // остальные байты, в том числе и 0 - читаем из буфера
        Value=fb[emu_byte++];
        // проверяем на последний байт
        if (emu_byte == 128) emu_stage=0;   // завершаем последовательность передачи данных
        break;
       }
      }
      case 1: {
/*
// k_mouse part
           if (PPI3_C & 0x10) {
              Value = (8-k_mousey) | (k_mouseb^0x30);
              k_mousey=0;
           } else {
              Value = (k_mousex+8) | (k_mouseb^0x30);
              k_mousex=0;
           }
           break;
*/
// deflector Joystick
             if (romboot == 1) Value=PPI3_B; // загрузка из ROM - читаем что записали, это адрес
             else Value=Read_Joystick();
             break;

      }
      case 2: {      
        if ((emuflag == 0)||(ex_flag == 1)) Value=PPI3_C;
        else Value=0x50;  // OBF=1  IBF=1
        break;
        }
      case 3: {return 0xff;break;}
    }
    return Value;
}

void PPI_Init(void)
{
 PPI1_C=AssembleVIREG_PPI1C();
 PPI2_C=Assemble_PPI2C();
}

#ifdef DBG
void ShowPPIdbg(void) {

 int i=0;
 int x=10;
 int y=657;
 char nc_rd[8][4] ={
                    "___",
                    "__1",
                    "_2_",
                    "_21",
                    "3__",
                    "3_1",
                    "32_",
                    "321",
                   };

 char tncreg[512];

 char tsysreg[32][40]={          
                       "0-37FF|3C00|    |3B00|3A00|3800",
                       "0-1FFF|    |    |    |    |    ",
                       "0-3FFF|    |    |    |    |    ",
                       "      |    |    |    |    |    ",
                       "0-1FFF|FC00|    |FB00|FA00|F800",
                       "0-1FFF|FC00|    |FB00|FA00|F800",
                       "0-3FFF|FC00|    |FB00|FA00|F800",
                       "      |FC00|    |FB00|FA00|F800",
                       "0-37FF|3C00|C000|3B00|3A00|3800",
                       "0-1FFF|    |C000|    |    |    ",
                       "0-3FFF|    |C000|    |    |    ",
                       "      |    |C000|    |    |    ",
                       "0-1FFF|    |4000|FE00|FF00|    ",
                       "0-1FFF|    |4000|FE00|FF00|    ",
                       "0-3FFF|    |4000|FE00|FF00|    ",
                       "      |    |4000|FE00|FF00|    ",
                       "0-5FFF|FC00|    |FB00|FA00|F800",
                       "0-1FFF|FC00|    |FB00|FA00|F800",
                       "0-3FFF|FC00|    |FB80|FA00|F800",
                       "      |FC00|    |FB00|FA00|F800",
                       "0-5FFF|    |    |FE00|FF00|    ",
                       "0-1FFF|    |    |FE00|FF00|    ",
                       "0-3FFF|    |    |FE00|FF00|    ",
                       "      |    |    |FE00|FF00|    ",
                       "0-5FFF|    |C000|    |BF00|    ",
                       "0-1FFF|    |C000|    |BF00|    ",
                       "0-3FFF|    |C000|    |BF00|    ",
                       "      |    |C000|    |BF00|    ",
                       "0-5FFF|    |C000|    |    |    ",
                       "0-1FFF|    |C000|    |    |    ",
                       "0-3FFF|    |C000|    |    |    ",
                       "      |    |C000|    |    |    ",
                      };

 if (NCREG & 0x80) { // Color MODE
   sprintf(tncreg,"COLOR: Read:%d (%s) Write:%d (%s)            ",
                 (NCREG>>4)&0x7,nc_rd[(NCREG>>4)&0x7],
                 (NCREG>>1)&0x7,nc_rd[(NCREG>>1)&0x7]
          );

 } else {
   sprintf(tncreg,"PLANE: Val: %d Read:%s Write:%s "
                 ,NCREG&1,nc_rd[(NCREG>>4)&0x7],nc_rd[((~NCREG)>>1)&0x7]);
 }

 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"           | ROM  |ACZU|GZU |RG  |PB  |KEY ");

 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"SysReg: %02x >%s",SYSREG<<2,tsysreg[SYSREG]);
 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"NCREG : %02x >%s",NCREG,tncreg);
 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"ViREG : %02x >GZU PAGE (Acess :%d Show:%d)",
                                             AssembleVIREG_PPI1C(),
                                             scr_Page_Acces,
                                             scr_Page_Show
           );
 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"            ACZU     (Attr:%d Wide:%d FONT2:%d)",
                                             scr_Attr_Write,
                                             scr_Wide_Mode,
                                             scr_Second_Font
           );
 textprintf_ex(screen,font,x,y+16*i++,0x20+0x07,0,"VBlank: %d",VBLANK);
}

#endif
